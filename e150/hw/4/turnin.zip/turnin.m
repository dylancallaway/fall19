dbstop if error
format compact
close all
clear
clc

[test] = myPrinter2(1)